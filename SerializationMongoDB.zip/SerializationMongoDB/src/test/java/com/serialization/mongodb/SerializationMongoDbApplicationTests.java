package com.serialization.mongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerializationMongoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
