package com.serialization.mongodb.modelBuilder;

import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.ClassModel;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.codecs.pojo.PropertyModelBuilder;

public class ClassModelBuilder<BirthdayInvitation> {

	private static final Class BirthdayInvitation = null;
	private static final String pojoCodecProvider = null;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	//org.bson.codecs.pojo
	//PropertyModelBuilder<Integer>classModel.getProperty("age")).propertySerialization(new CourteousAgeSerialization());
	
	//PojoCodecProvider pojoCodecProvider = PojoCodecProvider.builder().register(ClassModel.builder(null)).build();
	CodecRegistry pojoCodecRegistry  = fromRegistries(getDefaultCodecRegistry(), fromProviders(pojoCodecProvider));
	private Object getDefaultCodecRegistry() {
		// TODO Auto-generated method stub
		return null;
	}
	private CodecRegistry fromRegistries(Object defaultCodecRegistry, Object fromProviders) {
		// TODO Auto-generated method stub
		return null;
	}
	private Object fromProviders(String pojocodecprovider2) {
		// TODO Auto-generated method stub
		return null;
	}
}
