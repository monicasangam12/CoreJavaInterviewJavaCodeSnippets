package com.serialization.mongodb.entity;

import java.time.LocalDateTime;

public class BirthdayInvitation {

	private String name;
	private  Integer age;
	private  LocalDateTime eventDateTime;
	
	
	public BirthdayInvitation(String name, int age, LocalDateTime eventDateTime) {
		this.name  =  name;
		this.age  = age;
		this.eventDateTime = eventDateTime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public LocalDateTime getEventDateTime() {
		return eventDateTime;
	}
	public void setEventDateTime(LocalDateTime eventDateTime) {
		this.eventDateTime = eventDateTime;
	}
}
