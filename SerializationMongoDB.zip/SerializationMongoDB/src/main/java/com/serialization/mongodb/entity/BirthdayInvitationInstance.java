package com.serialization.mongodb.entity;

import java.time.LocalDateTime;
import java.time.Month;

import com.serialization.mongodb.modelBuilder.CourteousAgeSerialization;

public class BirthdayInvitationInstance {

	BirthdayInvitation  invitation = new BirthdayInvitation("Galaddriel", 7582, LocalDateTime.of(2021,Month.JANUARY, 18, 30, 0));
	
	public static void main (String  [] args) {
		CourteousAgeSerialization  courteousAge  = new CourteousAgeSerialization();
		courteousAge.shouldSerialize(32);
	}
}
