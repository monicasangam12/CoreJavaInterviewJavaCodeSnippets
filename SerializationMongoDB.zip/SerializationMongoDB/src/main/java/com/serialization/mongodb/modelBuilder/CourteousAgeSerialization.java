package com.serialization.mongodb.modelBuilder;

import org.bson.codecs.pojo.PropertySerialization;

public class CourteousAgeSerialization implements PropertySerialization<Integer> {

	@Override
	public boolean shouldSerialize(Integer value) {
	
		if(value > 30) {
			System.out.println("The  courteous  age of this person  from there birthday is serializable ");
		}else {
			System.out.println("The  courteous  age of this person  from there birthday is not serializable ");
		}
		
		return (value<30);
	}

}
