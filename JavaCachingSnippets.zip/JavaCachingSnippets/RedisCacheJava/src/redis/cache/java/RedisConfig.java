package redis.cache.java;

public class RedisConfig {

	private  static  final  String  REDIS_HOST = "localhost";
	private static final int REDIS_PORT  =  6379;
	
	
}
