package redis.cache.java;

//import redis.clients.jedis.Jedis;

public class RedisCache {
	
	private static final String  CACHE_KEY  = "myCacheKey";
	private  RedisConfig redisConfig;
	
	public RedisCache() {
		redisConfig = new RedisConfig();
	}
	
	public  void cacheData(String data) {
		System.out.println(data);
	}
//	
	public  String getCachedData(String cachedData) {
		System.out.println(cachedData);
		return cachedData;
	}

}
