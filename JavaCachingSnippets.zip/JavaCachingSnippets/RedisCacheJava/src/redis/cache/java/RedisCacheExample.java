package redis.cache.java;

public class RedisCacheExample {

	public static void main(String[] args) {
		RedisCache cacheExample = new RedisCache();
		cacheExample.cacheData("Hello, Redis!");
		
		String cachedData = cacheExample.getCachedData("cached data is returned!");
		System.out.println("Cached  Data: " + cachedData);
		

	}

}
