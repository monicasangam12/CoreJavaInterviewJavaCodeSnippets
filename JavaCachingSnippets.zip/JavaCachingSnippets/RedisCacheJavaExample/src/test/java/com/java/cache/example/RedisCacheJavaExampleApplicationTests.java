package com.java.cache.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisCacheJavaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
