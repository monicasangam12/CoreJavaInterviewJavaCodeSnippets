package com.java.cache.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.java.cache.example.service.ProductService;

@SpringBootApplication
public class RedisCacheJavaExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisCacheJavaExampleApplication.class, args);
		
		ProductService  productService =  new ProductService();
		productService.getProductById(1L);
		//productService.deleteProduct(2L);
	}

}
