package com.java.cache.example.service;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.java.cache.example.entity.Product;

@Service
public class ProductService {

	@Cacheable(value="products", key = "#id")
	public Product getProductById(Long id) {
		System.out.println();
		return  new  Product(id,"Product " +  id);
	}
	
	@CacheEvict(value="products",key="#id")
	public void deleteProduct(Long id) {
		System.out.println("Deleting product from database : "  + id);
	}
}
