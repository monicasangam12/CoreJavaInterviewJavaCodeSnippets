package memcached.java.example;

import java.io.IOException;
import java.net.InetSocketAddress;

import net.spy.memcached.MemcachedClient;

public class MemcachedJavaExample {

	public static void main(String[] args) throws IOException {
		String configEndpoint = "mycluster.fnjyo.cfg.use1.cache.amazonaws.com";
		Integer clusterPort =  11211;
		
		MemcachedClient client = new MemcachedClient(new InetSocketAddress(configEndpoint, clusterPort));
		
		client.set("theKey", 3600, "This is the data value ");
	}

}
