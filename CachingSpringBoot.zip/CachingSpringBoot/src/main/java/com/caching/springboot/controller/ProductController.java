package com.caching.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.RestController;

import com.caching.springboot.entity.Product;
import com.caching.springboot.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired 
	private ProductService productService;

	@Cacheable(value = "products", key = "#id", condition = "#id < 10")
	public Product getProductById(Long id) {
		try {
			Thread.sleep(3000); // Simulate delay
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new Product(id, "Sample Product");
	}
	
	@CachePut(value = "products", key = "#product.id")
	public Product updateProduct(Product product) {
		return product;
	}
	
	@CacheEvict(value = "products", key = "#id")
	public void deleteProduct(Long id) {
		productService.deleteProduct(id);
	}
	
	@CacheEvict(value = "products", allEntries = true)
	public void clearCache() {
		System.out.println("All cache entries cleared.");
	}
	
}
