package com.caching.springboot.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.caching.springboot.entity.Product;

@Service
public class ProductService {

	@Cacheable(value = "products", key = "#id")
	public Product getProductById(Long id) {
		try {
			Thread.sleep(3000); // Simulate delay
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new Product(id, "Sample Product");
	}

	public void deleteProduct(Long id) {
		System.out.println("Product with id " + id + " deleted.");
	}
}
