package com.caching.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CachingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
