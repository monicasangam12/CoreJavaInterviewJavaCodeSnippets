package com.serialization.redis;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.RedisTemplate;

@SpringBootApplication
public class SerializationRedisDbApplication {

	public static void main(String[] args) {
		//SpringApplication.run(SerializationRedisDbApplication.class, args);
		RedisTemplate<?, ?> redisTemplate = new RedisTemplate();
		System.out.println(redisTemplate);
	}

}
