package com.serialization.redis.template;

import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;

public class RedisTemplate{

	@SuppressWarnings({ "removal", "deprecation" })
	public RedisTemplate redisTemplatesStandAlone(LettuceConnectionFactory redisConnectionFactory){
		
		GenericJackson2JsonRedisSerializer serializer = new GenericJackson2JsonRedisSerializer();
		RedisTemplate redisTemplate = new RedisTemplate();
		redisTemplate.setConnectionFactory(redisConnectionFactory);
		System.out.println(redisTemplate);
		redisTemplate.setKeySerializer(serializer);
		redisTemplate.setValueSerializer(serializer);
		redisTemplate.afterPropertiesSet();
		return redisTemplate;
	}

	private void setKeySerializer(GenericJackson2JsonRedisSerializer serializer) {
		// TODO Auto-generated method stub
	
	}

	private void setValueSerializer(GenericJackson2JsonRedisSerializer serializer) {
		// TODO Auto-generated method stub
		
	}

	private void afterPropertiesSet() {
		// TODO Auto-generated method stub
		
	}

	private void setConnectionFactory(LettuceConnectionFactory redisConnectionFactory) {
		// TODO Auto-generated method stub
		
	}
}
