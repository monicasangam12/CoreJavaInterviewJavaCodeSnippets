/**
 * 
 */
/**
 * 
 */
module QueueInterfaceExample {
}