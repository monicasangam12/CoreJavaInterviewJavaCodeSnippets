package com.queue.interfaceExample.ArrayQueue;

public class ArrayQueueExample {
	private int [] arr;
	private int  capacity;
	private int size;
	
	public int [] getArr() {
		return arr;
	}

	public void setArr(int [] arr) {
		this.arr = arr;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
	public Object[] myQueue(int capacity) {
		this.setCapacity(capacity);
		setArr(new int[capacity]);
		setSize(0);
		return null;
	}

	public static void main(String[] args) {
		ArrayQueueExample  arrayQueue = new ArrayQueueExample();
		arrayQueue.myQueue(10);
		System.out.printf("Array  queue size and  capacity is : "  ,arrayQueue.myQueue(10));
	}

	

}
