package com.mapinterface.treemap;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapExample {

	public static void main(String[] args) {
	  TreeMap<Integer,String>studentRecords = new TreeMap<>();
	  
	  studentRecords.put(103, "Charlie");
	  studentRecords.put(101, "Alice");
	  studentRecords.put(102, "Bob");
	  studentRecords.put(104, "David");
	  
	  System.out.println("TreeMap: " + studentRecords);
	  
	  System.out.println("Student with key 102: " + studentRecords.get(102));
	  
	  for(Map.Entry<Integer, String>entry: studentRecords.entrySet()) {
		  System.out.println(entry.getKey() + " ->  " +  entry.getValue());
	  }

	}

}
