package com.mapinterface.linkedhashmap;

import java.util.LinkedHashMap;

public class LinkedHashMapExample{

	public static void main(String[] args) {
		LinkedHashMap<String, Integer>lhm  = new LinkedHashMap<>();
		lhm.put("Apple", 1);
		lhm.put("Banana", 2);
		lhm.put("Cherry", 3);
		lhm.put("Date", 4);
				
		System.out.println("LinkedHashMap  " +  lhm);
		
		int  bananaValue =  lhm.get("Banana");
		System.out.println("Value for  Banana: " + bananaValue);
		
		for(String key: lhm.keySet()) {
			System.out.println(key + "  -> " +  lhm.get(key));
		}

	}

}
