/**
 * 
 */
/**
 * 
 */
module MapInterfaceExample {
}