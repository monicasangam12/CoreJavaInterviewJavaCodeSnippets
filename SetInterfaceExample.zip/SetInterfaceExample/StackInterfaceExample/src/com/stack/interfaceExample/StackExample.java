package com.stack.interfaceExample;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		Stack<Integer> s = new Stack<>();
		s.push(10);
		s.push(15);
		s.push(30);
		s.push(20);
		s.push(40);
		
//		while(!s.isEmpty()) {
//			System.out.println(s.pop());
//		}
		
		System.out.println("Initial Stack: "   +  s);
		
		System.out.println("Popped element:  " +  s.pop());
		
		System.out.println("Popped element: " +  s.pop());
		
		System.out.println("Stack after pop operation " +  s);
		
		System.out.println("Is stack empty?" +  s.empty());
		
		s.pop();
		s.pop();
		s.pop();
		
		System.out.println("Is stack empty?" +  s.empty());

	}

}
