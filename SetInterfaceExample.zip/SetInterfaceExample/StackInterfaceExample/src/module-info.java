/**
 * 
 */
/**
 * 
 */
module StackInterfaceExample {
}