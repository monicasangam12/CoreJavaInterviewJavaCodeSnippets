package com.vector.example;

import java.util.Iterator;
import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
	
		Vector<String> vector  =  new Vector<>();
		vector.add("Dog");
		vector.add("Cat");
		vector.add("Rabbit");
		vector.add(0, "Fish");

		System.out.println("Vector elements: " + vector);
		
		String firstElement = vector.firstElement();
		String elementAtIndex2  =  vector.get(2);
		System.out.println("First  element:  " + firstElement);
		System.out.println("Element at index 2: "  + elementAtIndex2);
		
		vector.set(1, "Bird");
		System.out.println("Modified Vector: " + vector);
		
		vector.remove("Rabbit");
		System.out.println("After removing Rabbit: " + vector);
		
		System.out.println("Size of vector: " +  vector.size());
		System.out.println("Capacity of vector: " + vector.capacity());
		
		System.out.println("Iterating using an Iterator");
		Iterator<String> iterator  =  vector.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
	}

}
