package com.setinterface.example;

import java.util.HashSet;
import java.util.Set;

public class SetCollectionExample {

	public static void main(String[] args) {
		Set<String>uniqueNames =  new HashSet<>();
		uniqueNames.add("Bob");
		uniqueNames.add("Alice");
		uniqueNames.add("Charlie");
		
		uniqueNames.add("Alice");
		
		System.out.println("Contains Bob:  "  + uniqueNames.contains("Bob"));
		
		System.out.println("Set elements : "  + uniqueNames);

	}

}
