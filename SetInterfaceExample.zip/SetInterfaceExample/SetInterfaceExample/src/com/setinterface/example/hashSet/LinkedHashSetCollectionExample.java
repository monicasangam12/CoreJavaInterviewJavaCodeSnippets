package com.setinterface.example.hashSet;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetCollectionExample {

	public static void main(String[] args) {
		
		LinkedHashSet<String> set =  new LinkedHashSet<>();
		
		System.out.println("Initial LinkedHashSet: "  +  set);
		
		set.add("Apple");
		set.add("Banana");
		set.add("Cherry");
		set.add("Apple");
		set.add("Date");
		
		System.out.println("After adding elements: " + set);
		
		boolean wasRemoved = set.remove("banana");
		System.out.println("Attempted to remove Banana. Success" + wasRemoved);
		System.out.println("After removing Banana:  " + set);
		
		System.out.println("Iterating  through the set  using an Iterator");
		Iterator<String>iterator= set.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println("Does the  set contain Cherry?  " + set.contains("Cherry"));
		System.out.println("Does the  set  contain Mango?  "  +  set.contains("Mango"));
		
		System.out.println("Size of the set:  "  + set.size());
		
	}
	

}
