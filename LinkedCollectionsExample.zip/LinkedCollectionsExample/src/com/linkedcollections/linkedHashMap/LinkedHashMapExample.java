package com.linkedcollections.linkedHashMap;

import java.util.LinkedHashMap;

public class LinkedHashMapExample {

	public static void main(String[] args) {
		LinkedHashMap<String, String>capitalCities =  new LinkedHashMap<>();
		
		capitalCities.put("England", "London");
		capitalCities.put("India", "New Dehli");
		capitalCities.put("Austria", "wien");
		capitalCities.put("Norway", "Oslo");
		capitalCities.put("Norway", "Oslo");
		capitalCities.put("USA", "Washington DC");
		
		System.out.println(capitalCities);
	}

}
