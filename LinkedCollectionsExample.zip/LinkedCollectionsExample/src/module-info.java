/**
 * 
 */
/**
 * 
 */
module LinkedCollectionsExample {
}