package com.java.serializable;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializableDemoObject {

	public static void main(String[] args) {
		Employee  emp =  new Employee("John Doe", "123  Main St", 123456789, 101);
		
		try(FileOutputStream fileOut = new FileOutputStream("employee.ser")){
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(emp);
			System.out.println("Employee objeect serialization and saved to employee.ser");
	    }catch(IOException i) {
			i.printStackTrace();
		}
			
			
		
	}

}
