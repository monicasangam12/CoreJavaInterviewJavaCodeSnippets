package com.java.serializable;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializableDemoObject {

	public  static void main(String  [] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		Employee emp  = null;
		try(FileInputStream fis =  new FileInputStream("employee.ser");
			ObjectInputStream in =  new  ObjectInputStream(fis)){
			emp = (Employee) in.readObject();
			System.out.println("Employee  object deserialized successfully.");
			System.out.println("Name: "  +  emp.name);
			System.out.println("Address:  " +   emp.address);
			System.out.println("SSN  (transient, so defualt value 0:)"  + emp.SSN);
			System.out.println("Number:  "  +  emp.number);
		}catch(IOException i) {
			i.printStackTrace();
		}catch(ClassNotFoundException c) {
			System.out.println("Employee class not found.");
			c.printStackTrace();
		}
	}
}
