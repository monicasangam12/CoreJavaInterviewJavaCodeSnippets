package com.simplecache.example;

public class CacheEntry<V> {

	private final V value = null;
	private final long expiryTime = 0;
	
	public long getExpiryTime() {
		return expiryTime;
	}

	public V getValue() {
		return value;
	}
	
	public boolean  isExpired() {
		return System.currentTimeMillis() > expiryTime;
	}
	
}
