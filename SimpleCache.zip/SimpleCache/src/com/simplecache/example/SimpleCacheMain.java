package com.simplecache.example;

public class SimpleCacheMain {

	public static void main(String[] args) throws InterruptedException {
		SimpleCache<String, String>myCache =  new SimpleCache<>(2000);
		
		myCache.put("key1", "value1");
		myCache.put("key2", "value2");
		
		System.out.println("Key1: " +  myCache.get("key1"));
		System.out.println("Key2: " +  myCache.get("key2"));
		
		Thread.sleep(2500);
		
		System.out.println("Key1 after expiry: "+ myCache.get("key1"));
		System.out.println("Key2 after expiry: "+ myCache.get("key2"));
		
		myCache.put("key3", "value3");
		System.out.println("Key3: " + myCache.get("key3"));
		
		myCache.remove("key3");
		System.out.println("Key3  after  removal: " +  myCache.get("key3"));
		
		myCache.shutdown();
	}

}
