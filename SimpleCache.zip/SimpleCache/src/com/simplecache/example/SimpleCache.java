package com.simplecache.example;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class SimpleCache<K, V> {

	private Map<K, CacheEntry<V>> cache = null;
	private long timeToLiveMillis = 0;
	private ScheduledExecutorService scheduler = null;
	
	public SimpleCache(long timeToLiveMillis) {
		this.timeToLiveMillis =  timeToLiveMillis;
		this.cache = Collections.synchronizedMap(new HashMap<>());
		this.scheduler =  Executors.newSingleThreadScheduledExecutor();
		
		//scheduler.scheduleAtFixedRate(this::cleanupExpiredEntries, timeToLiveMillis/2, timeToLiveMillis/2, TimeUnit.MILLISECONDS);
	}
	
	public void put(K key, V value) {
		long expiryTime = System.currentTimeMillis() + timeToLiveMillis;
		System.out.println(expiryTime);
		cache.put(key, new CacheEntry<V>());
	}
	
	public V get(K key) {
		CacheEntry<V> entry = cache.get(key);
		if(entry!=null  && !entry.isExpired()) {
			return entry.getValue();
		}
		if(entry!=null  && !entry.isExpired()){
			cache.remove(key);
		}
		return null;
		
	}
	
	public void remove(K key) {
		cache.remove(key);
	}
	
	public void clear() {
		cache.clear();
	}
	
	
	@SuppressWarnings("unused")
	private void cleanupExpiredEntries() {
		cache.entrySet().removeIf(entry->entry.getValue().isExpired());
	}
	
	public void shutdown() {
		scheduler.shutdown();
	}

	public Map<K, CacheEntry<V>> getCache() {
		return cache;
	}


	public long getTimeToLiveMillis() {
		return timeToLiveMillis;
	}


	public ScheduledExecutorService getScheduler() {
		return scheduler;
	}

	
	
}
