package com.shapes.example;

public class ShapeInterfaceExample {

	public static void main(String[] args) {
		Shape circle  = new Circle(5.0);
		Shape rectangle =  new  Rectangle(4.0, 6.0);
		
		System.out.println("Circle Area: " +  circle.getArea());
		circle.printDescription();
		
		System.out.println("Rectangle Area: " +  rectangle.getArea());
		rectangle.printDescription();
	}

}
