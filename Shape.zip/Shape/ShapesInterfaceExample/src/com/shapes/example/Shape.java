package com.shapes.example;

public interface Shape {
	
	double getArea();
	
	default void printDescription() {
		System.out.println("This is a generic shape.");
	}

}
