/**
 * 
 */
/**
 * 
 */
module AbstractClassExamples {
}