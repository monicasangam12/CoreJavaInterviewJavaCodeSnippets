package com.abstractclass.example;

public abstract class BoardPiece {

	protected String color;
	
}
