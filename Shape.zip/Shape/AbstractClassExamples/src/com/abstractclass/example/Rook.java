package com.abstractclass.example;

public class Rook {

}
