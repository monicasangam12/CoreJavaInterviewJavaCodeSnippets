package com.finalIx.example;

public class FinalExample {
	 final int age = 20;
	 
	 public void display() {
		System.out.println("Age: " + age);
	}

	public static void main(String[] args) {
		FinalExample example = new FinalExample();
		example.display();
	}

}
