package com.finallyIx.example;

public class FinallyExample {

	public static void main(String[] args) {
		try {
			System.out.println("Inside try block");
			int data = 25 / 0; // This will cause ArithmeticException
			System.out.println("Data: " + data);
		}catch(ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
		} finally {
			System.out.println("Inside finally block always executes for cleanup");
		}
		System.out.println("Outside try-catch-finally");

	}

}
