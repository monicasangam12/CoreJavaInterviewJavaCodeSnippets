package com.finalizelx.example;

public class FinalizeExample {
	@SuppressWarnings("deprecation")
	@Override
	protected void finalize() throws Throwable {
		try {
			System.out.println("Finalize method called. Object is being garbage collected.");
		} finally {
			super.finalize();
		}
	}

	public static void main(String[] args) {
		FinalizeExample example = new FinalizeExample();
		System.out.println("Requesting garbage collection...");
		System.gc();
		System.out.println("Hashcode is: " + example.hashCode());
		example = null; 
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
