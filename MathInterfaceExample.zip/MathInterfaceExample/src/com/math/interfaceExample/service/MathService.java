package com.math.interfaceExample.service;

import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.ApplicationScope;

@Service
@ApplicationScope
public interface MathService {
	Integer AddNumbers(int firstNumber, int secondNumber);
	Integer SubtractNumbers(int firstNumber, int secondNumber);
}
