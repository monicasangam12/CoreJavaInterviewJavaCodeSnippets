package com.math.interfaceExample.service;

import org.springframework.http.ResponseEntity;

public class MathServiceImpl implements MathService {

	@Override
	public Integer AddNumbers(int firstNumber, int secondNumber) {
		Integer sum = firstNumber + secondNumber;
		return sum;
	}

	@Override
	public Integer SubtractNumbers(int firstNumber, int secondNumber) {
		Integer difference = firstNumber - secondNumber;
		return difference;
	}

}
