package com.math.interfaceExample.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.math.interfaceExample.service.MathService;

@RequestMapping("math")
@RestController
public class MathController {
	
	@Autowired
	private MathService mathService;

	@GetMapping("/add/{firstNumber}/{secondNumber}")
	public Integer Add(@PathVariable int firstNumber, @PathVariable int secondNumber) {
		return mathService.AddNumbers(firstNumber, secondNumber);
	}
	
	@GetMapping("/subtract/{firstNumber}/{secondNumber}")
	public Integer Subtract(@PathVariable int firstNumber, @PathVariable int secondNumber) {
		return mathService.SubtractNumbers(firstNumber, secondNumber);
	}
}
